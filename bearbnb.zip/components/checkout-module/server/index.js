const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const db = require('./db');

let app = express();

app.use(cors());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/rooms/:listingId', express.static(__dirname + '/../public'));

let port = 3002;

// calls getUsers to query the db with a variable listingId and returns the entry that matchs the params
app.get('/rooms/checkout/:listingId', (req, res) => {
  db.getRoom(req.params.listingId).then(records => {
    console.log('server get listings: ', records);
    res.send(records);
  });
});

app.get('/rooms/bookings/:listingId', (req, res) => {
  db.getBookings(req.params.listingId).then(records => {
    console.log('server get bookings: ', records);
    res.send(records);
  });
});

app.post('/rooms/checkout/:listingId', (req, res) => {
  console.log(req.body);
  db.bookRoom(req.params.listingId, req.body)
    .then(() => {
      res.end();
    });
});

var server = app.listen(port, function() {
  console.log(`listening on post ${port}`);
});

module.exports = server;